// Seoul Culture 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('Seoul Culture mini-app launched');
  },
  
  onShow() {
    console.log('Seoul Culture mini-app shown');
  },
  
  onHide() {
    console.log('Seoul Culture mini-app hidden');
  }
};