// Visit Busan 메인 페이지 로직
console.log("Visit Busan page loaded");

// 페이지 로드 시 자동으로 Visit Busan으로 이동
window.location.href = "https://www.247freepoker.com/";
