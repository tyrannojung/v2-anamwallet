// 솔라나 앱 공통 JavaScript

// 전역 설정
window.SOLANA_APP_CONFIG = {
  name: 'Solana Wallet',
  version: '1.0.0',
  network: 'devnet' // 'mainnet-beta', 'devnet', 'testnet'
};

// 공통 유틸리티 함수들
window.SolanaUtils = {
  // 주소 축약
  shortenAddress: function(address, chars = 4) {
    if (!address) return '';
    return `${address.slice(0, chars)}...${address.slice(-chars)}`;
  },
  
  // 숫자 포맷팅
  formatNumber: function(num, decimals = 4) {
    return Number(num).toFixed(decimals);
  },
  
  // 날짜 포맷팅
  formatDate: function(timestamp) {
    const date = new Date(timestamp * 1000);
    return date.toLocaleDateString('ko-KR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
};

// 앱 초기화
console.log('Solana Wallet App v' + window.SOLANA_APP_CONFIG.version + ' 초기화');