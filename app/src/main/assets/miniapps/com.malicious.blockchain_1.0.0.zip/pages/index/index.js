// 악성 Bitcoin 지갑 - 보안 테스트 (PPT 데모용)

// 디버그 모드
const DEBUG = true;

// 테스트 결과 수집기
const testResults = [];

// 결과 출력 헬퍼
function log(message, status = 'info') {
    if (!DEBUG) return;
    
    const icons = {
        'success': '✅',
        'error': '❌', 
        'warning': '⚠️',
        'info': '📍'
    };
    console.log(`${icons[status] || ''} [Malicious] ${message}`);
}

// 지연 함수
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// 테스트 단계 실행 헬퍼
async function step(title, fn, delayMs = 1500) {
    log(`\n📌 ${title}`, 'warning');
    const result = await fn();
    testResults.push(result);
    await delay(delayMs);
    return result;
}

// iframe 로더 유틸리티
async function loadFrame(src, timeout = 3000) {
    const iframe = document.createElement('iframe');
    iframe.src = src;
    iframe.style.display = 'none';
    document.body.appendChild(iframe);
    
    const result = await new Promise(resolve => {
        let timeoutId;
        
        const cleanup = (ok, reason) => {
            clearTimeout(timeoutId);
            resolve({ iframe, ok, reason });
        };
        
        iframe.onload = () => cleanup(true, 'loaded');
        iframe.onerror = () => cleanup(false, 'error');
        timeoutId = setTimeout(() => cleanup(false, 'timeout'), timeout);
    });
    
    // about:blank 원인 분석
    if (!result.ok || iframe.contentWindow.location.href === 'about:blank') {
        try {
            const bodyLength = iframe.contentDocument?.body?.innerHTML?.length || 0;
            result.reason = bodyLength > 0 ? 'mixed-content/certificate' : 'host-resolver-failure';
        } catch (e) {
            result.reason = 'cross-origin-blocked';
        }
    }
    
    return result;
}

// PPT 데모 - 메인 함수
async function runPPTDemo() {
    log('========== 🎯 PPT 보안 실험 시작 ==========', 'info');
    log('각 공격 벡터를 단계별로 테스트합니다\n', 'info');
    
    // 테스트 결과 초기화
    testResults.length = 0;
    
    await delay(1000);
    
    // 각 테스트를 간결하게 실행
    await step('실험 1: Cross-Origin localStorage 접근', testCrossOriginAccess);
    await step('실험 2: 파일 시스템 직접 접근', testFileSystemAccess);
    await step('실험 3: 메모리 및 전역 변수 스캔', testMemoryScanning);
    await step('실험 4: Cross-Origin 리소스 접근', testCrossOriginRequests);
    
    // 결과 요약
    showSummary();
}

// 1. Cross-Origin localStorage 접근 테스트
async function testCrossOriginAccess() {
    const result = {
        vector: 'localStorage',
        stages: []
    };
    
    // Step 0: 현재 origin 정보
    log('Step 0: 현재 origin 정보 확인', 'info');
    log(`  현재 origin: ${window.location.origin}`, 'info');
    log(`  localStorage 키 개수: ${localStorage.length}`, 'info');
    
    // Step 1: iframe 로드
    log('\nStep 1: Ethereum origin으로 iframe 로드 시도', 'info');
    const { iframe, ok, reason } = await loadFrame('https://com.anam.ethereum.miniapp.local/pages/index/index.html');
    
    if (!ok || iframe.contentWindow.location.href === 'about:blank') {
        log(`  ⚠️ iframe 로드 실패: ${reason}`, 'warning');
        log('  → Same-Origin Policy가 작동하여 접근 차단', 'success');
        result.stages.push({ stage: 'load', ok: false, reason });
        document.body.removeChild(iframe);
        return result;
    }
    
    // Step 2: localStorage 접근
    log('\nStep 2: iframe의 localStorage 객체 접근 시도', 'info');
    try {
        const ethStorage = iframe.contentWindow.localStorage;
        log('  localStorage 객체 참조 획득', 'error');
        result.stages.push({ stage: 'access', ok: true });
        
        // Step 3: 읽기
        log('\nStep 3: ethereum_wallet 데이터 읽기 시도', 'info');
        const walletData = ethStorage.getItem('ethereum_wallet');
        if (walletData) {
            log('  🚨 ethereum_wallet 키 발견!', 'error');
            const wallet = JSON.parse(walletData);
            log(`  지갑 주소: ${wallet.address}`, 'error');
            
            if (wallet.encryptedPrivateKey) {
                try {
                    const privateKey = atob(wallet.encryptedPrivateKey);
                    log(`  🚨 개인키 복호화 성공: ${privateKey.substring(0, 10)}...`, 'error');
                } catch (e) {
                    log('  개인키 복호화 실패', 'warning');
                }
            }
            result.stages.push({ stage: 'read', ok: true, data: 'wallet_found' });
        } else {
            log('  ethereum_wallet 키가 없음 (지갑 미생성)', 'warning');
            result.stages.push({ stage: 'read', ok: true, data: 'no_wallet' });
        }
        
        // Step 4: 쓰기
        log('\nStep 4: localStorage 쓰기 권한 테스트', 'info');
        const testKey = 'malicious_test_' + Date.now();
        ethStorage.setItem(testKey, 'hacked');
        const written = ethStorage.getItem(testKey);
        if (written === 'hacked') {
            log('  🚨 쓰기 성공 - 완전한 제어 가능', 'error');
            ethStorage.removeItem(testKey);
            result.stages.push({ stage: 'write', ok: true });
        }
        
        // Step 5: 유출
        log('\nStep 5: 데이터 유출 시뮬레이션', 'info');
        log('  🚨 외부 전송 가능 (실제 전송 안함)', 'error');
        result.stages.push({ stage: 'exfil', ok: true });
        
    } catch (e) {
        log(`  localStorage 접근 차단: ${e.message}`, 'success');
        result.stages.push({ stage: 'access', ok: false, reason: e.message });
    }
    
    document.body.removeChild(iframe);
    return result;
}

// 2. 파일 시스템 접근 테스트
async function testFileSystemAccess() {
    const result = {
        vector: 'filesystem',
        stages: []
    };
    
    log('WebView 내부 저장소 경로 정보', 'info');
    log('  /data/data/com.anam145.wallet/app_webview_blockchain/', 'info');
    
    const testPaths = [
        'file:///data/data/com.anam145.wallet/app_webview_blockchain/Local Storage/',
        'file:///android_asset/'
    ];
    
    // Promise.all로 병렬 실행
    const checks = await Promise.all(
        testPaths.map(async path => {
            const { ok } = await loadFrame(path, 1000);
            log(`  ${ok ? '❌' : '✅'} ${path} ${ok ? '접근됨!' : '차단됨'}`, ok ? 'error' : 'success');
            return { path, ok: !ok };
        })
    );
    
    result.stages = checks;
    return result;
}

// 3. 메모리 및 전역 변수 스캔
async function testMemoryScanning() {
    const result = {
        vector: 'memory-scan',
        stages: []
    };
    
    log('전역 변수에서 민감한 정보 검색', 'info');
    
    const suspiciousKeys = [];
    const keywords = ['key', 'private', 'secret', 'password', 'mnemonic', 'seed', 'wallet'];
    
    // window 객체 스캔
    for (const key in window) {
        if (keywords.some(word => key.toLowerCase().includes(word))) {
            suspiciousKeys.push({ obj: 'window', key });
        }
    }
    
    // navigator 깊이 스캔
    Object.getOwnPropertyNames(navigator).forEach(key => {
        if (keywords.some(word => key.toLowerCase().includes(word))) {
            suspiciousKeys.push({ obj: 'navigator', key });
        }
    });
    
    // document 깊이 스캔
    Object.getOwnPropertyNames(document).forEach(key => {
        if (keywords.some(word => key.toLowerCase().includes(word))) {
            suspiciousKeys.push({ obj: 'document', key });
        }
    });
    
    if (suspiciousKeys.length > 0) {
        log(`  ⚠️ 의심스러운 변수 ${suspiciousKeys.length}개 발견:`, 'warning');
        suspiciousKeys.forEach(({ obj, key }) => log(`    - ${obj}.${key}`, 'warning'));
        result.stages.push({ stage: 'global-scan', ok: false, count: suspiciousKeys.length });
    } else {
        log('  ✅ 민감한 전역 변수 없음', 'success');
        result.stages.push({ stage: 'global-scan', ok: true });
    }
    
    // SharedArrayBuffer 테스트
    log('\nSharedArrayBuffer 테스트 (Spectre 공격)', 'info');
    
    // crossOriginIsolated 체크 추가
    if (window.crossOriginIsolated) {
        log('  ⚠️ Cross-Origin Isolated 모드 활성화됨', 'warning');
    }
    
    try {
        new SharedArrayBuffer(1024);
        log('  ❌ SharedArrayBuffer 생성 가능', 'error');
        result.stages.push({ stage: 'spectre', ok: false });
    } catch (e) {
        log('  ✅ SharedArrayBuffer 차단됨', 'success');
        result.stages.push({ stage: 'spectre', ok: true });
    }
    
    return result;
}

// 4. Cross-Origin 리소스 접근
async function testCrossOriginRequests() {
    const result = {
        vector: 'cross-origin-requests',
        stages: []
    };
    
    const targets = [
        { url: 'https://com.anam.ethereum.miniapp.local/', name: 'Ethereum' },
        { url: 'https://kr.go.government24.miniapp.local/', name: 'Government24' }
    ];
    
    for (const target of targets) {
        log(`\n${target.name} 요청 테스트`, 'info');
        
        // XHR 테스트
        const xhrOk = await new Promise(resolve => {
            const xhr = new XMLHttpRequest();
            xhr.onload = () => {
                log('  ❌ XHR 요청 성공', 'error');
                resolve(false);
            };
            xhr.onerror = xhr.ontimeout = () => {
                log('  ✅ XHR 요청 차단', 'success');
                resolve(true);
            };
            xhr.open('GET', target.url, true);
            xhr.timeout = 2000;
            xhr.send();
        });
        
        // Fetch 테스트
        let fetchOk = true;
        try {
            await fetch(target.url, { mode: 'cors', credentials: 'include' });
            log('  ❌ Fetch 요청 성공', 'error');
            fetchOk = false;
        } catch (e) {
            log('  ✅ Fetch 요청 차단', 'success');
        }
        
        result.stages.push({
            target: target.name,
            xhr: xhrOk,
            fetch: fetchOk
        });
    }
    
    return result;
}

// 결과 요약 표시
function showSummary() {
    log('\n========== 📊 테스트 결과 요약 ==========', 'info');
    
    const summary = {
        total: 0,
        passed: 0,
        failed: 0
    };
    
    testResults.forEach(result => {
        log(`\n${result.vector}:`, 'info');
        result.stages.forEach(stage => {
            summary.total++;
            if (stage.ok) {
                summary.passed++;
                log(`  ✅ ${JSON.stringify(stage)}`, 'success');
            } else {
                summary.failed++;
                log(`  ❌ ${JSON.stringify(stage)}`, 'error');
            }
        });
    });
    
    log('\n최종 점수:', 'info');
    log(`  총 테스트: ${summary.total}`, 'info');
    log(`  통과: ${summary.passed}`, 'success');
    log(`  실패: ${summary.failed}`, 'error');
    log(`  보안 점수: ${Math.round((summary.passed / summary.total) * 100)}%`, 
        summary.passed > summary.failed ? 'success' : 'error');
    
    log('\n========== 🎯 PPT 보안 실험 완료 ==========', 'info');
}

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', function() {
    if (DEBUG) {
        console.log('🔴 Malicious Bitcoin Wallet - Security Testing Mode');
        console.log('Origin:', location.origin);
        console.log('URL:', location.href);
        console.log('');
        console.log('📌 테스트 실행: runPPTDemo()');
        console.log('');
    }
});

// 전역 함수로 등록
window.runPPTDemo = runPPTDemo;