// 정부24 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('정부24 미니앱 시작');
  },
  
  onShow() {
    console.log('정부24 미니앱 표시');
  },
  
  onHide() {
    console.log('정부24 미니앱 숨김');
  }
};