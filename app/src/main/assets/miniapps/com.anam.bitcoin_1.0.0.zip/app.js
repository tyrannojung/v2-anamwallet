// 비트코인 지갑 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('비트코인 지갑 미니앱 시작');
  },
  onShow() {
    console.log('비트코인 지갑 미니앱 표시');
  },
  onHide() {
    console.log('비트코인 지갑 미니앱 숨김');
  }
};