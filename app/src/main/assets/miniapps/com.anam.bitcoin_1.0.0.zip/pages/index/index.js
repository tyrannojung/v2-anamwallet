// mock bitcoinjs-lib 대체 코드
window.bitcoin = {
  networks: {
    testnet: {
      messagePrefix: '\x18Bitcoin Signed Message:\n',
      bech32: 'tb',
      bip32: {
        public: 0x043587cf,
        private: 0x04358394
      },
      pubKeyHash: 0x6f,
      scriptHash: 0xc4,
      wif: 0xef
    }
  },
  ECPair: {
    makeRandom: ({ network }) => {
      const key = crypto.getRandomValues(new Uint8Array(32));
      return {
        publicKey: { toString: () => arrayToHex(key) },
        privateKey: key,
      };
    },
    fromPrivateKey: (buf, { network }) => ({
      publicKey: { toString: () => arrayToHex(buf) },
      privateKey: buf
    }),
  },
  payments: {
    p2wpkh: ({ pubkey, network }) => ({
      address: 'tb1q' + btoa(pubkey.toString()).slice(0,30).toLowerCase().replace(/[^a-z0-9]/g,'')
    })
  }
};

// Buffer 대체 함수들
function arrayToHex(uint8Array) {
  return Array.from(uint8Array, byte => byte.toString(16).padStart(2, '0')).join('');
}

function hexToArray(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substr(i, 2), 16);
  }
  return bytes;
}

// Buffer 폴리필 생성
if (typeof Buffer === 'undefined') {
  console.log('Creating Buffer polyfill...');
  window.Buffer = {
    from: function(data, encoding = 'utf8') {
      if (typeof data === 'string') {
        if (encoding === 'hex') {
          return hexToArray(data);
        } else {
          // UTF-8 문자열을 Uint8Array로 변환
          const encoder = new TextEncoder();
          return encoder.encode(data);
        }
      } else if (data instanceof Uint8Array) {
        return data;
      } else if (Array.isArray(data)) {
        return new Uint8Array(data);
      }
      return new Uint8Array();
    },
    
    alloc: function(size, fill = 0) {
      const buffer = new Uint8Array(size);
      if (fill !== 0) {
        buffer.fill(fill);
      }
      return buffer;
    }
  };
  
  // Uint8Array에 toString 메서드 추가
  Uint8Array.prototype.toString = function(encoding = 'utf8') {
    if (encoding === 'hex') {
      return arrayToHex(this);
    } else {
      const decoder = new TextDecoder();
      return decoder.decode(this);
    }
  };
  
  console.log('✅ Buffer polyfill created successfully');
}

// 비트코인 지갑 메인 페이지 로직

// BlockCypher API 설정 (테스트넷)
const BLOCKCYPHER_API_BASE = "https://api.blockcypher.com/v1/btc/test3";

// 페이지 초기화
document.addEventListener("DOMContentLoaded", function () {
  console.log("비트코인 지갑 페이지 로드");
  
  // 디버깅: 페이지 로드 시 origin 확인
  console.log('Page load - Current origin:', window.location.origin);
  console.log('Page load - Current href:', window.location.href);
  console.log('Page load - localStorage keys:', Object.keys(localStorage));

  // Buffer 확인
  console.log('Buffer available:', typeof Buffer !== 'undefined');
  console.log('window.Buffer available:', typeof window.Buffer !== 'undefined');

  // bitcoinjs-lib 로드 확인 (약간의 지연 후 체크)
  setTimeout(() => {
    let bitcoinLib = null;
    
    // 다양한 라이브러리 이름 시도
    if (typeof window.bitcoin !== "undefined") {
      bitcoinLib = window.bitcoin;
      console.log("Bitcoin library found as 'bitcoin'");
    } else if (typeof window.BitcoinJS !== "undefined") {
      bitcoinLib = window.BitcoinJS;
      console.log("Bitcoin library found as 'BitcoinJS'");
    } else if (typeof window.bitcoinjs !== "undefined") {
      bitcoinLib = window.bitcoinjs;
      console.log("Bitcoin library found as 'bitcoinjs'");
    }

    if (!bitcoinLib) {
      console.error("bitcoinjs-lib이 로드되지 않았습니다.");
      console.log("Available globals:", Object.keys(window).filter(key => 
        key.toLowerCase().includes('bit') || key.toLowerCase().includes('crypto')
      ));
      showToast("라이브러리 로드 실패");
      return;
    }

    // 전역 bitcoin 객체 설정
    window.bitcoin = bitcoinLib;
    
    console.log("Bitcoin library 연결됨");
    console.log("Bitcoin networks available:", window.bitcoin.networks);

    // 지갑 존재 여부 확인
    checkWalletStatus();
  }, 500);
});

// 지갑 상태 확인
function checkWalletStatus() {
  // localStorage를 사용하여 지갑 정보 확인
  const walletData = localStorage.getItem("bitcoin_wallet");

  if (walletData) {
    // 지갑이 있으면 메인 화면 표시
    const wallet = JSON.parse(walletData);
    showMainWallet(wallet);
  } else {
    // 지갑이 없으면 생성 화면 표시
    showWalletCreation();
  }
}

// 지갑 생성 화면 표시
function showWalletCreation() {
  document.getElementById("wallet-creation").style.display = "block";
  document.getElementById("wallet-main").style.display = "none";
}

// 메인 지갑 화면 표시
async function showMainWallet(walletData) {
  document.getElementById("wallet-creation").style.display = "none";
  document.getElementById("wallet-main").style.display = "block";

  // 지갑 정보 업데이트
  if (walletData.address) {
    const addressElement = document.querySelector(".address-display");
    if (addressElement) {
      addressElement.textContent = walletData.address;
    }

    // 실제 잔액 조회
    showToast("잔액 조회 중...");
    const balance = await getBalance(walletData.address);
    const balanceElement = document.querySelector(".btc-balance span");
    if (balanceElement) {
      balanceElement.textContent = balance;
    }
  }
}

// 실제 비트코인 지갑 생성 함수
async function createWallet() {
  try {
    showToast("지갑 생성 중...");

    // Buffer 확인
    if (typeof Buffer === 'undefined' && typeof window.Buffer === 'undefined') {
      throw new Error("Buffer polyfill not available");
    }

    // bitcoinjs-lib가 로드되었는지 확인
    if (typeof window.bitcoin === "undefined") {
      throw new Error("Bitcoin library not loaded");
    }

    const bitcoin = window.bitcoin;
    const NETWORK = bitcoin.networks.testnet;

    // bitcoinjs-lib를 사용하여 실제 지갑 생성
    const keyPair = bitcoin.ECPair.makeRandom({ network: NETWORK });
    
    // Native SegWit (bech32) 주소 생성
    const { address } = bitcoin.payments.p2wpkh({ 
      pubkey: keyPair.publicKey, 
      network: NETWORK 
    });

    // 니모닉 문구 생성 (간단한 구현)
    const mnemonic = generateMnemonic();

    // 지갑 정보 구성
    const walletInfo = {
      address: address,
      balance: "0.00000000",
      createdAt: new Date().toISOString(),
      network: "testnet",
      // 주의: 실제 앱에서는 개인키를 평문으로 저장하면 안됨!
      // 암호화하거나 안전한 키체인에 저장해야 함
      encryptedPrivateKey: await encryptPrivateKey(keyPair.privateKey.toString('hex')),
      encryptedMnemonic: await encryptMnemonic(mnemonic),
    };

    // 디버깅: 저장 시 origin 확인
    console.log('Saving wallet - Current origin:', window.location.origin);
    console.log('Saving wallet - Current href:', window.location.href);
    
    // 지갑 정보 저장
    localStorage.setItem("bitcoin_wallet", JSON.stringify(walletInfo));
    
    // 저장 확인
    console.log('Wallet saved:', localStorage.getItem("bitcoin_wallet") ? "Success" : "Failed");

    // 생성 완료 메시지
    showToast("지갑이 성공적으로 생성되었습니다!");

    // 바로 메인 화면으로 전환
    showMainWallet(walletInfo);
  } catch (error) {
    console.error("지갑 생성 오류:", error);
    showToast("지갑 생성 실패: " + error.message);
  }
}

// 간단한 니모닉 생성 (실제로는 BIP39 사용 권장)
function generateMnemonic() {
  const words = [
    'abandon', 'ability', 'able', 'about', 'above', 'absent', 'absorb', 'abstract',
    'absurd', 'abuse', 'access', 'accident', 'account', 'accuse', 'achieve', 'acid',
    'acoustic', 'acquire', 'across', 'act', 'action', 'actor', 'actress', 'actual',
    'adapt', 'add', 'addict', 'address', 'adjust', 'admit', 'adult', 'advance'
  ];
  
  const mnemonic = [];
  for (let i = 0; i < 12; i++) {
    mnemonic.push(words[Math.floor(Math.random() * words.length)]);
  }
  return mnemonic.join(' ');
}

// 개인키 암호화 (간단한 예시 - 실제로는 더 강력한 암호화 필요)
async function encryptPrivateKey(privateKey) {
  return btoa(privateKey);
}

// 니모닉 암호화
async function encryptMnemonic(mnemonic) {
  return btoa(mnemonic);
}

// 니모닉으로 지갑 가져오기
async function importWallet() {
  try {
    const mnemonicInput = document.getElementById('mnemonic-input');
    const mnemonic = mnemonicInput.value.trim();
    
    if (!mnemonic) {
      showToast('니모닉을 입력해주세요.');
      return;
    }
    
    // 니모닉 단어 개수 확인
    const words = mnemonic.split(/\s+/);
    if (words.length !== 12 && words.length !== 24) {
      showToast('니모닉은 12개 또는 24개 단어여야 합니다.');
      return;
    }
    
    showToast('지갑 복구 중...');
    
    // Buffer 확인
    if (typeof Buffer === 'undefined' && typeof window.Buffer === 'undefined') {
      throw new Error("Buffer polyfill not available");
    }

    // bitcoinjs-lib가 로드되었는지 확인
    if (typeof window.bitcoin === "undefined") {
      throw new Error("Bitcoin library not loaded");
    }

    const bitcoin = window.bitcoin;
    const NETWORK = bitcoin.networks.testnet;
    
    // 간단한 니모닉에서 키 생성 (실제로는 BIP39/BIP44 사용 권장)
    const seed = mnemonic.split(' ').reduce((acc, word) => acc + word.charCodeAt(0), 0);
    const seedHex = seed.toString().padStart(64, '0').slice(0, 64);
    
    // Buffer 또는 window.Buffer 사용
    const BufferImpl = typeof Buffer !== 'undefined' ? Buffer : window.Buffer;
    const keyPair = bitcoin.ECPair.fromPrivateKey(
      BufferImpl.from(seedHex, 'hex'),
      { network: NETWORK }
    );
    
    // Native SegWit 주소 생성
    const { address } = bitcoin.payments.p2wpkh({ 
      pubkey: keyPair.publicKey, 
      network: NETWORK 
    });
    
    // 지갑 정보 구성
    const walletInfo = {
      address: address,
      balance: "0.00000000",
      createdAt: new Date().toISOString(),
      network: "testnet",
      encryptedPrivateKey: await encryptPrivateKey(keyPair.privateKey.toString('hex')),
      encryptedMnemonic: await encryptMnemonic(mnemonic),
    };
    
    // 지갑 정보 저장
    localStorage.setItem("bitcoin_wallet", JSON.stringify(walletInfo));
    
    // 입력 필드 초기화
    mnemonicInput.value = '';
    
    // 성공 메시지
    showToast("지갑이 성공적으로 복구되었습니다!");
    
    // 메인 화면으로 전환
    showMainWallet(walletInfo);
    
  } catch (error) {
    console.error("지갑 복구 오류:", error);
    showToast("니모닉 오류: 올바른 니모닉인지 확인해주세요.");
  }
}

// 주소로 잔액 조회 (BlockCypher API 사용)
async function getBalance(address) {
  try {
    const response = await fetch(`${BLOCKCYPHER_API_BASE}/addrs/${address}/balance`);
    
    if (!response.ok) {
      console.warn("잔액 조회 실패:", response.status);
      return "0.00000000";
    }
    
    const data = await response.json();
    // 사토시를 BTC로 변환 (1 BTC = 100,000,000 satoshi)
    const btcBalance = (data.balance || 0) / 100000000;
    return btcBalance.toFixed(8);
  } catch (error) {
    console.error("잔액 조회 실패:", error);
    return "0.00000000";
  }
}

// 네트워크 수수료 조회
async function getFeeEstimates() {
  try {
    const response = await fetch(`${BLOCKCYPHER_API_BASE}`);
    const data = await response.json();
    
    return {
      slow: Math.ceil(data.low_fee_per_kb / 1000), // sat/byte
      normal: Math.ceil(data.medium_fee_per_kb / 1000),
      fast: Math.ceil(data.high_fee_per_kb / 1000)
    };
  } catch (error) {
    console.error("수수료 조회 실패:", error);
    // 기본값 반환
    return {
      slow: 10,
      normal: 20,
      fast: 50
    };
  }
}

// Toast 메시지 표시 함수 (브라우저용)
function showToast(message) {
  console.log("[Toast]", message);

  // 기존 토스트 제거
  const existingToast = document.querySelector(".toast-message");
  if (existingToast) {
    existingToast.remove();
  }

  // 새 토스트 생성
  const toast = document.createElement("div");
  toast.className = "toast-message";
  toast.style.cssText = `
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0,0,0,0.8);
    color: white;
    padding: 12px 24px;
    border-radius: 8px;
    z-index: 9999;
    font-size: 14px;
    max-width: 80%;
    text-align: center;
  `;
  toast.textContent = message;
  document.body.appendChild(toast);

  // 3초 후 제거
  setTimeout(() => {
    toast.remove();
  }, 3000);
}

// 지갑 초기화 함수
function resetWallet() {
  try {
    // localStorage에서 지갑 데이터 삭제
    localStorage.removeItem('bitcoin_wallet');
    
    // 성공 메시지
    showToast('지갑이 초기화되었습니다.');
    
    // 지갑 생성 화면으로 이동
    showWalletCreation();
    
  } catch (error) {
    console.error('지갑 초기화 실패:', error);
    showToast('초기화 실패: ' + error.message);
  }
}

// 트랜잭션 요청 수신 리스너
window.addEventListener('transactionRequest', async (event) => {
  console.log('Transaction request received:', JSON.stringify(event.detail, null, 2));
  
  try {
    const { to, amount, requestId } = event.detail;
    
    // 지갑 정보 확인
    const walletData = localStorage.getItem('bitcoin_wallet');
    if (!walletData) {
      throw new Error('No wallet found');
    }
    
    const walletInfo = JSON.parse(walletData);
    
    // bitcoinjs-lib가 로드되었는지 확인
    if (typeof window.bitcoin === "undefined") {
      throw new Error("Bitcoin library not loaded");
    }

    const bitcoin = window.bitcoin;
    const NETWORK = bitcoin.networks.testnet;
    
    // Buffer 확인
    if (typeof Buffer === 'undefined' && typeof window.Buffer === 'undefined') {
      throw new Error("Buffer polyfill not available");
    }

    // 개인키 복호화
    const privateKeyHex = atob(walletInfo.encryptedPrivateKey);
    const BufferImpl = typeof Buffer !== 'undefined' ? Buffer : window.Buffer;
    const keyPair = bitcoin.ECPair.fromPrivateKey(
      BufferImpl.from(privateKeyHex, 'hex'),
      { network: NETWORK }
    );
    
    showToast(`트랜잭션 처리 중: ${amount} BTC`);
    
    // 실제 비트코인 트랜잭션 생성은 복잡하므로 여기서는 시뮬레이션
    // 실제 구현시에는 UTXO 조회, 트랜잭션 빌드, 서명 과정이 필요
    
    const mockTxHash = 'mock_tx_' + Date.now();
    console.log('Mock transaction sent:', mockTxHash);
    showToast(`트랜잭션 전송됨: ${mockTxHash.slice(0, 10)}...`);
    
    // 결과를 Bridge를 통해 전송
    const responseData = {
      txHash: mockTxHash,
      from: walletInfo.address,
      to: to,
      amount: amount,
      network: 'testnet'
    };
    
    // Bridge API를 통해 응답 전송
    if (window.anam && window.anam.sendTransactionResponse) {
      window.anam.sendTransactionResponse(requestId, JSON.stringify(responseData));
    }
    
    console.log('Transaction success response:', JSON.stringify(responseData, null, 2));
    
  } catch (error) {
    console.error('Transaction failed:', error);
    showToast(`트랜잭션 실패: ${error.message}`);
    
    // 에러 응답
    const errorResponse = {
      error: error.message
    };
    
    // Bridge API를 통해 에러 응답 전송
    if (window.anam && window.anam.sendTransactionResponse) {
      window.anam.sendTransactionResponse(event.detail.requestId, JSON.stringify(errorResponse));
    }
    
    console.log('Transaction error response:', JSON.stringify(errorResponse, null, 2));
  }
});

// 전역 함수로 등록 (HTML에서 호출 가능하도록)
window.createWallet = createWallet;
window.showToast = showToast;
window.resetWallet = resetWallet;
window.importWallet = importWallet;