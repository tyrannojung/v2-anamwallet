// Coin 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('Coin 지갑 미니앱 시작');
  },
  onShow() {
    console.log('Coin 지갑 미니앱 표시');
  },
  onHide() {
    console.log('Coin 지갑 미니앱 숨김');
  }
};