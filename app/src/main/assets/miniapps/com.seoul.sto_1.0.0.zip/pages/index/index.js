// STO (Seoul Tourism Organization) 메인 페이지 로직
console.log('STO page loaded');

// 페이지 로드 시 자동으로 STO로 이동
window.location.href = "https://www.sto.or.kr/english/index";