// STO (Seoul Tourism Organization) 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('STO mini-app launched');
  },
  
  onShow() {
    console.log('STO mini-app shown');
  },
  
  onHide() {
    console.log('STO mini-app hidden');
  }
};