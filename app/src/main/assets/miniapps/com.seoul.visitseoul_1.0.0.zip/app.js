// Visit Seoul 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('Visit Seoul mini-app launched');
  },
  
  onShow() {
    console.log('Visit Seoul mini-app shown');
  },
  
  onHide() {
    console.log('Visit Seoul mini-app hidden');
  }
};